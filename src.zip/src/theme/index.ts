
import theme from './theme';
import ThemeManager, { ThemeContext } from './ThemeContext';
export {
	ThemeContext,
	ThemeManager,
	theme,
};
