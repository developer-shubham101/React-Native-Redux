export const appOptions = {
  url: 'https://dogwalkergame.ezxdemo.com/',
  home_cms_block_id: '19',
  store: 'default', // store code // Stores > All Stores > Store View > Code
  authentication: {
    integration: {
      access_token: 'cdlodltsj3wfwd1jrx08q9nfprb5idq4',
    },
  },
};
