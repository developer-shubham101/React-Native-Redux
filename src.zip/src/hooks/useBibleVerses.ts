import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getVersesList } from '../actions';
import { BookList, ReducerRoot } from '../type';

export default function useBibleVerses(id: string | undefined) {
  const verses = useSelector<ReducerRoot, any>((state) => state.bible.verses);
  console.log('Max::::verses', { verses });

  // const [currentBook, setCurrentBook] = useState<BookList | null | undefined>();
  // const [loading, setLoading] = useState<boolean>(true);
  const [chapter, setChapter] = useState<string | undefined>(id);
  const [verse, setVerse] = useState();

  const dispatch = useDispatch();

  // useEffect(() => {
  //   if (book) {
  //     setCurrentBook(book);
  //     setLoading(false);
  //   } else {
  //     setLoading(true);
  //   }
  // }, [book]);

  useEffect(() => {
    if (verses && chapter && verses[chapter]) {
      setVerse(verses[chapter]);
    } else if (chapter) {
      dispatch(getVersesList(chapter));
    }
  }, [chapter, verses]);

  const getVerses = (id: string) => {
    setChapter(id);
  };

  return { verse, /* currentBook, loading,  */ getVerses };
}
