import './i18n';

export * from './translate';
