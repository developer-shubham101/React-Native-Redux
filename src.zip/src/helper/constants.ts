export const USER_TOKEN_KEY = 'UserToken';
export const USER_DETAILS_KEY = 'UserDetails';
export const IS_WALKTHROUGH_FINISH = 'IS_WALKTHROUGH';
export const CART_DATA = 'CART';
export const FCM_TOKEN = 'FCM_TOKEN';




export const ACTIVE = 'active';
export const PENDING = 'pending';