export const ADMIN_TYPE = 'admin_type';
export const GUEST_TYPE = 'guest_type';
export const CUSTOMER_TYPE = 'customer_type';
