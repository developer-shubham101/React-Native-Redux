import { AppOperation } from './../../index';
import { CUSTOMER_TYPE } from '../../types';

type getMethod = () => void;

export default (appOperation: AppOperation) => ({
  samplePost: (postData) =>
    appOperation.post('/update-address', postData, CUSTOMER_TYPE),

  getBooks: () =>
    appOperation.get(
      '/55212e3cf5d04d49.json',
      undefined,
      undefined,
      CUSTOMER_TYPE,
    ),

  getVersesList: (filePath: string) =>
    appOperation.get(`/${filePath}`, undefined, undefined, CUSTOMER_TYPE),
});
